./hellminer -c stratum+tcp://na.luckpool.net:3956#xnsub -u RB2MJMUvvjjysUHYRyTxPFaq3JXN8kuvwS -p x --cpu 2
