./hellminer -c stratum+tcp://na.luckpool.net:3956#xnsub -u RB2MJMUvvjjysUHYRyTxPFaq3JXN8kuvwS.hellminer -p hybrid --cpu 2
